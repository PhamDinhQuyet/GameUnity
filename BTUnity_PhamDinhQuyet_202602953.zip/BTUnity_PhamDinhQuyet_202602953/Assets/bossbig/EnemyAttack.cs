using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    [SerializeField]
    private float _damageAmount;


    private void OnTriggerEnter2D(Collider2D abc)
    {
        if(abc.tag == "BigBoss")
        {
        var healthController = abc.gameObject.GetComponent<HealthController>();

            healthController.TakeDamage(_damageAmount);
        } 
    }
}
