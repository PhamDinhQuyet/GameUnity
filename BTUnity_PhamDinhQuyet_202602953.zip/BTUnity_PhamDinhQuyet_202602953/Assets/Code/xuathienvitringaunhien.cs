﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class xuathienvitringaunhien : MonoBehaviour
{
    public GameObject playerPrefab;
    void Start()
    {
        // Tạo một vị trí ngẫu nhiên trên màn hình
        Vector3 randomPosition = new Vector3(Random.Range(-10f, 10f), 0, Random.Range(-10f, 10f));
        // Instantiate player object tại vị trí ngẫu nhiên
        Instantiate(playerPrefab, randomPosition, Quaternion.identity);
    }
}
