﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dichuyen : MonoBehaviour
{
    public float moveSpeed = 5f;
    private Rigidbody2D rb;
    private Vector3 MoveInput;

    public Animator animator;


    public float rollBoost =5f;
    private float rollTime;
    public float RollTime;
    bool rollOnce = false;
    private void Start()
    {
        animator = GetComponent<Animator>();
    }
    private void Update()
    {   // di chuyển
        MoveInput.x = Input.GetAxis("Horizontal");
        MoveInput.y = Input.GetAxis("Vertical");
        transform.position += MoveInput * moveSpeed * Time.deltaTime;

        if(Input.GetKeyDown(KeyCode.Space) && rollTime <=0)
        {
            animator.SetBool("Bool", true);
            moveSpeed += rollBoost;
            rollTime = RollTime;
            rollOnce = true;
        }
        if (rollTime <=0 && rollOnce == true)
            
        {
            animator.SetBool("Bool", false);
            moveSpeed -= rollBoost;
            rollOnce = false;
        }
        else
        {
            rollTime -= Time.deltaTime;
        }
        //di chuyển chạy
        animator.SetFloat("Speed", MoveInput.sqrMagnitude);
        //thay đổi góc độ
        if(MoveInput.x != 0)
        {
            if (MoveInput.x > 0)
                transform.localScale = new Vector3(1, 1, 0);
            else
                transform.localScale = new Vector3(-1, 1, 0);
        }
    }
}    


