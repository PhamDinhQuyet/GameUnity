using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bossvachamvoiphayer : MonoBehaviour
{
    [SerializeField]
    private float _damageAmount = 10;

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            var healthController = collision.gameObject.GetComponent<heathPhayer>();

            healthController.TakeDamage(_damageAmount);
        }
    }
}
