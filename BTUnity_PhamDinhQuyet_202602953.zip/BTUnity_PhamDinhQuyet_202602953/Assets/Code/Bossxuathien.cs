﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bossxuathien : MonoBehaviour
{
    public GameObject[] enemies; // Mảng chứa các quái vật
    void Start()
    {
        InvokeRepeating("SpawnEnemy", 5f, 5f); // Lặp lại phương thức SpawnEnemy sau mỗi 5 giây
    }
    void SpawnEnemy()
    {
        int rand = Random.Range(0, enemies.Length); // Lấy ngẫu nhiên một quái vật từ mảng
        Instantiate(enemies[rand], transform.position, transform.rotation); // Tạo một quái vật tại vị trí của EnemySpawner
    }
}
