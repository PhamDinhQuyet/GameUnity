﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Playagain : MonoBehaviour
{
    private string mainSceneName;
    private void Start()
    {
        // Lấy tên cảnh chính
        mainSceneName = SceneManager.GetActiveScene().name; 
        Time.timeScale = 1;
    }
    public void OnClickPlayAgainButton()
    {
        // Tải lại cảnh chính
        SceneManager.LoadScene(mainSceneName);
     
    }
}
