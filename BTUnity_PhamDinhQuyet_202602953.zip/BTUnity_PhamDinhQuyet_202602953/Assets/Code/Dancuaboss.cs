using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dancuaboss : MonoBehaviour
{
    public GameObject bullet;
    public float timeBtwFire;
    public float bulletSpeed;
    private float fireCooldown;
    private void Update()
    {
        fireCooldown -= Time.deltaTime;
        if (fireCooldown < 0f)
        {
            fireCooldown = timeBtwFire;
            //shot
            EnemyFireBullet();
        }
    }
    void EnemyFireBullet()
    {
        var bulletTmnp = Instantiate(bullet, transform.position, Quaternion.identity);
        Rigidbody2D rb = bulletTmnp.GetComponent<Rigidbody2D>();
        Vector3 playerPos = FindObjectOfType<dichuyen>().transform.position;
        Vector3 direction = playerPos - transform.position;
        rb.AddForce(direction.normalized * bulletSpeed, ForceMode2D.Impulse);
    }
}
