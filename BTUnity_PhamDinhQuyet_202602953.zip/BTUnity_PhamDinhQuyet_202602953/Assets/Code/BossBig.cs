using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossBig : MonoBehaviour
{
    public mauboss mauBoss;
    public GameObject boss;
    public float timeToSpawn = 2f;
    private float timer;
    private void Start()
    {
        timer = 0;
    }
    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= timeToSpawn)
        {
            boss.gameObject.SetActive(true);
            mauBoss.gameObject.SetActive(true);
          timer = 0;
        }
      
    }
    /*
    void SpawnBoss()

    { 
     
        Instantiate(boss, transform.position, Quaternion.identity);
    }*/
    /*public GameObject bossPrefab;
    public float timeBeforeBossAppears = 10f;
    private float timeSinceGameStart = 0f;
    private bool waitingForBossAppearance = false;
    // Start is called before the first frame update
    void Start()
    {
        waitingForBossAppearance = true;
    }
    // Update is called once per frame
    void Update()
    {
        timeSinceGameStart += Time.deltaTime;
        if (waitingForBossAppearance && timeSinceGameStart >= timeBeforeBossAppears)
        {
            SpawnBoss();
            waitingForBossAppearance = false;
        }
    }
    void SpawnBoss()
    {
        // Spawn boss at random position on the map
        Vector3 spawnPosition = new Vector3(Random.Range(-10f, 10f), 0f, Random.Range(-10f, 10f));
        Instantiate(bossPrefab, spawnPosition, Quaternion.identity);
    }*/
}


