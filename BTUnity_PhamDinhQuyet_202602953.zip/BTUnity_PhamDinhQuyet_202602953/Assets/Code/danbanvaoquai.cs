﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class danbanvaoquai : MonoBehaviour
{

    public int health = 5; // Số lần bắn cần để quái vật biến mất
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Boss")
        {
            health--;
            if (health <= 0)
            {
                Destroy(collision.gameObject);
                Destroy(gameObject);
            }
        }
        if (collision.tag == "dan")
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
            

        }
    }
}
