using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class mau : MonoBehaviour
{
    // Start is called before the first frame update
    public Image fillBar;
    public TextMeshProUGUI valueText;
    public void UpdateBar(float currenValue, float maxValue)
    {
        fillBar.fillAmount = (float)currenValue / (float)maxValue;
        valueText.text = currenValue.ToString() + "/" + maxValue.ToString();
    }
}
