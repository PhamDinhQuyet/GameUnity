﻿using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

using UnityEngine.UI;

public class EndGame : MonoBehaviour
{
    public AudioSource aus;
    public AudioClip Win;
    public Button playagin;
    //Khởi tạo biến kiểm tra chiến thắng
    public Image Chienthang;
    //Hàm xử lý khi player chạm vào object để chiến thắng
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {   
            Chienthang.gameObject.SetActive(true);
            playagin.gameObject.SetActive(true);
            Time.timeScale = 0f;
            if(aus && Win)
            {
                aus.PlayOneShot(Win);
            }

        }



    }
  }