using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class vacham1lan : MonoBehaviour
{
    [SerializeField]
    private float _invincibilityDuration;

    private tancong _invincibilityController;

    private void Awake()
    {
        _invincibilityController = GetComponent<tancong>();
    }

    public void StartInvincibility()
    {
        _invincibilityController.StartInvincibility(_invincibilityDuration);
    }
}
